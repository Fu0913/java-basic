package com.briup.homework.day19;

import java.io.Serializable;
import java.util.Comparator;

public class Teacher implements Serializable, Comparable<Teacher> {
    private String name;
    private int age;
    private double salary;

    public Teacher() {}
    public Teacher(String name, int age, double salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Teacher{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", salary=" + salary +
                '}';
    }

    @Override
    public int compareTo(Teacher o2) {
        Teacher o1 = this;

        int r;
        //按工资降序
        if(o2.getSalary() > o1.getSalary())
            r = 1;
        else if(o2.getSalary() < o1.getSalary())
            r = -1;
        else
            r = 0;

        //按年龄升序
        if(r == 0) {
            r = o1.getAge() - o2.getAge();

            //按名称升序
            if(r == 0) {
                r = o1.getName().compareTo(o2.getName());
            }
        }

        //保留属性完全重复的元素
        return (r == 0) ? 1 : r;
    }
}
