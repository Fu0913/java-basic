package com.briup.homework.day19;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;

/*
    接收客户端发送过来的对象(包含所有老师)，遍历输出，
    完成后返回给客户端一个信息: "ok"
    最后关闭服务器！
 */
public class Test02_TcpServer {
    //使用Collections.sort进行排序【推荐】
    public static void main(String[] args) throws Exception {
        //1.搭建服务器
        ServerSocket server = new ServerSocket(8989);
        System.out.println("服务器启动成功，端口: 8989");

        //2.接受客户端的连接
        Socket socket = server.accept();
        System.out.println("客户端连接成功: " + socket);

        //3.获取IO流并封装
        //读取对象
        InputStream is = socket.getInputStream();
        ObjectInputStream ois = new ObjectInputStream(is);
        //发送字符串
        OutputStream os = socket.getOutputStream();
//        OutputStreamWriter osw = new OutputStreamWriter(os);
//        BufferedWriter bw = new BufferedWriter(osw);
        PrintStream ps = new PrintStream(os);

        //4.接受客户端发送的集合对象
        List<Teacher> list = (List<Teacher>) ois.readObject();
        //遍历集合对象
        for(Teacher t : list) {
            System.out.println(t);
        }

        //对集合中Teacher对象进行排序：先按照工资降序，再按照年龄升序，最后按名称升序
        //  注意，属性完全相同的老师全部保留
        //额外提供比较算法
        Comparator<Teacher> comp = new Comparator<Teacher>() {
            @Override
            public int compare(Teacher o1, Teacher o2) {
                int r;
                //按工资降序
                if(o2.getSalary() > o1.getSalary())
                    r = 1;
                else if(o2.getSalary() < o1.getSalary())
                    r = -1;
                else
                    r = 0;

                //按年龄升序
                if(r == 0) {
                    r = o1.getAge() - o2.getAge();

                    //按名称升序
                    if(r == 0) {
                        r = o1.getName().compareTo(o2.getName());
                    }
                }

                return r;
            }
        };

        //使用集合工具类进行排序
        Collections.sort(list,comp);
        System.out.println("排序后: " + list);

        //将集合对象，写入到本地文件src/dir/teacher.txt
        ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream("src/dir/teacher.txt"));

        //如果要序列化TreeSet对象(使用比较器排序)，则该比较器对象 也要实现序列化接口，
        // 否则运行会抛出异常：未实现序列化接口
        oos.writeObject(list);
        System.out.println("list 成功写入 本地文件!");
        //流使用完，及时关闭
        oos.close();

        //5.返回信息给 客户端
        ps.println("ok");
        System.out.println("成功发送数据给客户端!");

        //6.关闭资源
        System.out.println("服务器即将关闭!");
        ps.close();
        ois.close();
        socket.close();
        server.close();
    }

    //使用 TreeSet+自定义比较器对象 进行排序
    public static void main01(String[] args) throws Exception {
        //1.搭建服务器
        ServerSocket server = new ServerSocket(8989);
        System.out.println("服务器启动成功，端口: 8989");

        //2.接受客户端的连接
        Socket socket = server.accept();
        System.out.println("客户端连接成功: " + socket);

        //3.获取IO流并封装
        //读取对象
        InputStream is = socket.getInputStream();
        ObjectInputStream ois = new ObjectInputStream(is);
        //发送字符串
        OutputStream os = socket.getOutputStream();
//        OutputStreamWriter osw = new OutputStreamWriter(os);
//        BufferedWriter bw = new BufferedWriter(osw);
        PrintStream ps = new PrintStream(os);

        //4.接受客户端发送的集合对象
        List<Teacher> list = (List<Teacher>) ois.readObject();
        //遍历集合对象
        for(Teacher t : list) {
            System.out.println(t);
        }

        //对集合中Teacher对象进行排序：先按照工资降序，再按照年龄升序，最后按名称升序
        //  注意，属性完全相同的老师全部保留
        //额外提供比较算法
//        Comparator<Teacher> comp = new Comparator<Teacher>() {
//            @Override
//            public int compare(Teacher o1, Teacher o2) {
//                int r;
//                //按工资降序
//                if(o2.getSalary() > o1.getSalary())
//                    r = 1;
//                else if(o2.getSalary() < o1.getSalary())
//                    r = -1;
//                else
//                    r = 0;
//
//                //按年龄升序
//                if(r == 0) {
//                    r = o1.getAge() - o2.getAge();
//
//                    //按名称升序
//                    if(r == 0) {
//                        r = o1.getName().compareTo(o2.getName());
//                    }
//                }
//
//                //保留属性完全重复的元素
//                return (r == 0) ? 1 : r;
//            }
//        };
        MyComparator comp = new MyComparator();
        TreeSet<Teacher> set = new TreeSet<>(comp);
        set.addAll(list);
        System.out.println("排序后: " + set);

        //将集合对象，写入到本地文件src/dir/teacher.txt
        ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream("src/dir/teacher.txt"));

        //如果要序列化TreeSet对象(使用比较器排序)，则该比较器对象 也要实现序列化接口，
        // 否则运行会抛出异常：未实现序列化接口
        oos.writeObject(set);
        System.out.println("set 成功写入 本地文件!");
        //流使用完，及时关闭
        oos.close();

        //5.返回信息给 客户端
        ps.println("ok");
        System.out.println("成功发送数据给客户端!");

        //6.关闭资源
        System.out.println("服务器即将关闭!");
        ps.close();
        ois.close();
        socket.close();
        server.close();
    }
}

//定义比较器类  实现 序列化接口
class MyComparator implements Comparator<Teacher>,Serializable {
    @Override
    public int compare(Teacher o1, Teacher o2) {
        int r;
        //按工资降序
        if (o2.getSalary() > o1.getSalary())
            r = 1;
        else if (o2.getSalary() < o1.getSalary())
            r = -1;
        else
            r = 0;

        //按年龄升序
        if (r == 0) {
            r = o1.getAge() - o2.getAge();

            //按名称升序
            if (r == 0) {
                r = o1.getName().compareTo(o2.getName());
            }
        }

        //保留属性完全重复的元素
        return (r == 0) ? 1 : r;
    }
}
