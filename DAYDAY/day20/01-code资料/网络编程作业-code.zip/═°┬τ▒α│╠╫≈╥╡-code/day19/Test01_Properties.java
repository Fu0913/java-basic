package com.briup.homework.day19;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class Test01_Properties {
    public static void main(String[] args) throws IOException {
        //1.实例化工具类对象
        Properties prop = new Properties();

        //2.导入配置文件
        prop.load(new FileInputStream("src/dir/stu.properties"));

        //3.获取学生属性
        String id = prop.getProperty("id");
        String name = prop.getProperty("name");
        String addr = prop.getProperty("addr");
        String ageStr = prop.getProperty("age");
        // String --> int
        int age = Integer.parseInt(ageStr);

//        System.out.println(id + " " + name + " " + addr + " " + age);

        //4.实例化对象
        Student s = new Student(id,name,addr,age);
        System.out.println(s);

        //5.修改学生对象属性值
        s.setName("tom");
        s.setAddr("shanghai");
        //修改配置文件工具类 键值对
        prop.setProperty("name",s.getName());
        prop.setProperty("addr",s.getAddr());

        //6.将配置对象 键值对重写 写入 配置文件
        prop.store(new FileOutputStream("src/dir/stu.properties"),null);
        System.out.println("操作完成");
    }
}
