package com.briup.homework.day19;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/*
    从键盘录入老师信息，录入格式：姓名-年龄-工资，遇quit结束录入
    zs-31-8900
    tom-28-7893.5
    ww-33-4536.5
    ...
    quit
    将每行信息封装成老师对象，然后发送到服务器
    再收取服务器返回的信息并输出
    最后关闭客户端！
 */
public class Test02_TcpClient {
    //验证按照 -分隔符来 分割
    public static void main00(String[] args) {
        String str = "tom-12-23.5";
        String[] arr = str.split("-");
        System.out.println(arr.length);
    }

    public static void main(String[] args) throws IOException {
        //1.搭建TCP客户端
        Socket socket = new Socket("127.0.0.1",8989);
        System.out.println("客户端成功连接到服务器: " + socket);

        //2.获取IO流
        //接受字符串，采用缓冲字符流
        InputStream is = socket.getInputStream();
        InputStreamReader isr = new InputStreamReader(is);
        BufferedReader br = new BufferedReader(isr);

        //发送对象，采用对象流
        OutputStream os = socket.getOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(os);

        //3.从键盘录入老师信息，封装成对象
        Scanner sc = new Scanner(System.in);
        System.out.println("录入老师信息，格式: 姓名-年龄-工资");
        //准备集合 存储所有的老师对象
        List<Teacher> list = new ArrayList<>();
        while(true) {
            String line = sc.nextLine();
            //遇到quit则结束录入
            if("quit".equals(line))
                break;

            String[] arr = line.split("-");
            String name = arr[0];
            int age = Integer.parseInt(arr[1]);
            double salary = Double.parseDouble(arr[2]);

            Teacher t = new Teacher(name,age,salary);
//            System.out.println(t);
            list.add(t);
        }

        //4.将集合发送到服务器
        oos.writeObject(list);
        System.out.println("集合数据发送成功!");

        //5.接受服务器返回信息
        String msg = br.readLine();
        System.out.println("read: " + msg);

        //6.关闭流，关闭TCP客户端
        System.out.println("客户端即将关闭!");
        oos.close();
        br.close();
        socket.close();
    }
}
